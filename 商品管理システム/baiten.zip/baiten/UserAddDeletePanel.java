package baiten;

import javax.swing.JPanel;

public class UserAddDeletePanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public UserAddDeletePanel() {

	}

}
