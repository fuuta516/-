package baiten;

import javax.swing.JPanel;

public class SalesPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public SalesPanel() {

	}

}
