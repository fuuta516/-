package baiten;

import javax.swing.JPanel;

public class GoodsAddDeletePanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public GoodsAddDeletePanel() {

	}

}
