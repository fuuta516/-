package baiten;

import javax.swing.JPanel;

public class UserPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public UserPanel() {

	}

}
