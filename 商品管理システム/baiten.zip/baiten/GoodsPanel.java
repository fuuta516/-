package baiten;

import javax.swing.JPanel;

public class GoodsPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public GoodsPanel() {

	}

}
